const revelarOnePlayer = (valor) => {
  let numeroAleatorio = 0;
  function alterarNumero() {
    // Gere um número aleatório de 1 a 10
    numeroAleatorio = Math.floor(Math.random() * 10) + 1;
    // Atualize o valor do h1 com o número aleatório
    document.getElementById("secretNumber").textContent = numeroAleatorio;
  }

  // Chame a função inicialmente
  alterarNumero();

  // Agende a função para ser chamada a cada 800 milissegundos (0.8 segundo) durante 10 segundos
  const intervalo = setInterval(alterarNumero, 800);
  setTimeout(() => {
    // Pare o intervalo após 10 segundos
    clearInterval(intervalo);
    if (numeroAleatorio == valor) {
      alert("Parabéns player você acertou o número secreto: " + numeroAleatorio);
      window.location.reload();
    } else {
      alert("Não foi dessa vez player você errou o número secreto era " + numeroAleatorio);
      window.location.reload();
    }
  }, 10000);
};

document.getElementById("meuFormulario").addEventListener("submit", function (event) {
  event.preventDefault(); // Evita o envio padrão do formulário
  revelarOnePlayer(document.getElementById("playerInput").value);
});
